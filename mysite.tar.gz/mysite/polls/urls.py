from django.conf.urls import url,include
from django.urls import path, re_path
from . import views

urlpatterns = [
path('', views.index, name = "index"),
re_path(r'(?P<q_id>[0-9]+)/$', views.details, name="details")
]