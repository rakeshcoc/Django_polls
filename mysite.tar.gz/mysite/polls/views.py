from django.shortcuts import render
from .models import Question 
# Create your views here.
from django.template import loader, RequestContext
from django.http import HttpResponse

def index(request):
	latest_q = Question.objects.order_by('-pub_date')[:5]
	context = {
		'latest_q' : latest_q
		}
	return render(request,'polls/index.html',context)

def details(request,q_id):
	question = Question.objects.get(pk= q_id)
	context = {'question': question}
	return render(request,'polls/details.html',context)